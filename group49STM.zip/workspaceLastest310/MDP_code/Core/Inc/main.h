/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ICM20948_ADDR.h"
#include "ICM20948_OPTIONS.h"
#include "ICM20948.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define OLED_SCL_Pin GPIO_PIN_5
#define OLED_SCL_GPIO_Port GPIOE
#define OLED_SDA_Pin GPIO_PIN_6
#define OLED_SDA_GPIO_Port GPIOE
#define MOTOR_AIN2_Pin GPIO_PIN_2
#define MOTOR_AIN2_GPIO_Port GPIOA
#define MOTOR_AIN1_Pin GPIO_PIN_3
#define MOTOR_AIN1_GPIO_Port GPIOA
#define MOTOR_BIN1_Pin GPIO_PIN_4
#define MOTOR_BIN1_GPIO_Port GPIOA
#define MOTOR_BIN2_Pin GPIO_PIN_5
#define MOTOR_BIN2_GPIO_Port GPIOA
#define OLED_RST_Pin GPIO_PIN_7
#define OLED_RST_GPIO_Port GPIOE
#define OLED_DC_Pin GPIO_PIN_8
#define OLED_DC_GPIO_Port GPIOE
#define LED3_Pin GPIO_PIN_10
#define LED3_GPIO_Port GPIOE
#define Trig_Pin GPIO_PIN_11
#define Trig_GPIO_Port GPIOE
/* USER CODE BEGIN Private defines */
/*#define OLED_SCL_Pin GPIO_PIN_5
#define OLED_SCL_GPIO_Port GPIOE
#define OLED_SDA_Pin GPIO_PIN_6
#define OLED_SDA_GPIO_Port GPIOE
#define MOTOR_AIN2_Pin GPIO_PIN_2
#define MOTOR_AIN2_GPIO_Port GPIOA
#define MOTOR_AIN1_Pin GPIO_PIN_3
#define MOTOR_AIN1_GPIO_Port GPIOA
#define MOTOR_BIN1_Pin GPIO_PIN_4
#define MOTOR_BIN1_GPIO_Port GPIOA
#define MOTOR_BIN2_Pin GPIO_PIN_5
#define MOTOR_BIN2_GPIO_Port GPIOA
#define OLED_RST_Pin GPIO_PIN_7
#define OLED_RST_GPIO_Port GPIOE
#define OLED_DC_Pin GPIO_PIN_8
#define OLED_DC_GPIO_Port GPIOE
#define LED3_Pin GPIO_PIN_10
#define LED3_GPIO_Port GPIOE*/
//#define Trig_Pin GPIO_PIN_11
//#define Trig_GPIO_Port GPIOE
//#define Echo_Pin GPIO_PIN_5
//#define Echo_GPIO_Port GPIOB


#define AIN2_Pin GPIO_PIN_2
#define AIN2_GPIO_Port GPIOA
#define AIN1_Pin GPIO_PIN_3
#define AIN1_GPIO_Port GPIOA
#define BIN1_Pin GPIO_PIN_4
#define BIN1_GPIO_Port GPIOA
#define BIN2_Pin GPIO_PIN_5
#define BIN2_GPIO_Port GPIOA
#define PWMA_Pin GPIO_PIN_6
#define PWMA_GPIO_Port GPIOC


#define PI 3.141592654
#define WHEEL_LENGTH 20
#define PPR 330

#define SPEED_MODE_T 0
#define SPEED_MODE_1 1
#define SPEED_MODE_2 2

#define INIT_DUTY_SPT_L 1200
#define INIT_DUTY_SPT_R 1200
#define DUTY_SPT_RANGE 600

#define INIT_DUTY_SP1_L 500
#define INIT_DUTY_SP1_R 500
#define DUTY_SP1_RANGE 400

#define INIT_DUTY_SP2_L 2500
#define INIT_DUTY_SP2_R 2500
#define DUTY_SP2_RANGE 700


#define SERVO_LEFT_MAX 70
//#define SERVO_CENTER 74
#define SERVO_CENTER 150
#define SERVO_RIGHT_MAX 250

#define IR_CONST_A 25644.81557
#define IR_CONST_B 260.4233354
#define IR_SAMPLE 50

// iT WAS 100


#define MIN_SPEED_SCALE 0.4 // INIT_DUTY_SP1_L / INIT_DUTY_SP2_L

#define SERVO_TURN_TIME 300

//#define SERVO_TURN_TIME 300

#define DIST_M 1.150067316
#define DIST_C 0.965311399

#define DIR_FORWARD 1
#define DIR_BACKWARD 0



#define __Gyro_Read_Z(_I2C, readGyroData, gyroZ) ({ \
	HAL_I2C_Mem_Read(_I2C,ICM20948__I2C_SLAVE_ADDRESS_1 << 1, ICM20948__USER_BANK_0__GYRO_ZOUT_H__REGISTER, I2C_MEMADD_SIZE_8BIT, readGyroData, 2, 0xFFFF); \
	gyroZ = readGyroData[0] << 8 | readGyroData[1]; \
})

#define __ADC_Read_Dist(_ADC, dataPoint, IR_data_raw_acc, obsDist, obsTick) ({ \
	dataPoint=0; \
	while(dataPoint < IR_SAMPLE - 1){ \
		HAL_ADC_Start(_ADC); \
		HAL_ADC_PollForConversion(_ADC,20); \
		IR_data_raw_acc += HAL_ADC_GetValue(_ADC); \
		dataPoint = (dataPoint + 1) % IR_SAMPLE; \
	} \
	obsDist = IR_CONST_A / (IR_data_raw_acc / dataPoint - IR_CONST_B); \
	obsTick = IR_data_raw_acc / dataPoint; \
	IR_data_raw_acc = 0; \
})

#define __PID_SPEED_T(cfg, error, correction, dir, newDutyL, newDutyR) ({ \
	correction = (cfg).Kp * error + (cfg).Ki * (cfg).ekSum + (cfg).Kd * (error-(cfg).ek1);\
	(cfg).ek1 = error; \
	(cfg).ekSum += error; \
	correction = correction > DUTY_SPT_RANGE ? DUTY_SPT_RANGE : (correction < -DUTY_SPT_RANGE ? -DUTY_SPT_RANGE : correction); \
	newDutyL = INIT_DUTY_SPT_L + correction*dir; \
	newDutyR = INIT_DUTY_SPT_R - correction*dir; \
})

#define __PID_SPEED_1(cfg, error, correction, dir, newDutyL, newDutyR) ({ \
	correction = (cfg).Kp * error + (cfg).Ki * (cfg).ekSum + (cfg).Kd * (error-(cfg).ek1);\
	(cfg).ek1 = error; \
	(cfg).ekSum += error; \
	correction = correction > DUTY_SP1_RANGE ? DUTY_SP1_RANGE : (correction < -DUTY_SP1_RANGE ? -DUTY_SP1_RANGE : correction); \
	newDutyL = INIT_DUTY_SP1_L + correction*dir; \
	newDutyR = INIT_DUTY_SP1_R - correction*dir; \
})

#define __PID_SPEED_2(cfg, error, correction, dir, newDutyL, newDutyR) ({ \
	correction = (cfg).Kp * error + (cfg).Ki * (cfg).ekSum + (cfg).Kd * (error-(cfg).ek1);\
    (cfg).ek1 = error; \
	(cfg).ekSum += error; \
	correction = correction > DUTY_SP2_RANGE ? DUTY_SP2_RANGE : (correction < -DUTY_SP2_RANGE ? -DUTY_SP2_RANGE : correction); \
	newDutyL = INIT_DUTY_SP2_L + correction*dir; \
	newDutyR = INIT_DUTY_SP2_R - correction*dir; \
})

// important one
// CHANGE NEWDUTYR 2500 - 4000

#define __PID_SPEED_2US(cfg, error, correction, dir, newDutyL, newDutyR) ({ \
	correction = (cfg).Kp * error + (cfg).Ki * (cfg).ekSum + (cfg).Kd * (error-(cfg).ek1);\
    (cfg).ek1 = error; \
	(cfg).ekSum += error; \
	correction = correction > DUTY_SP2_RANGE ? DUTY_SP2_RANGE : (correction < -DUTY_SP2_RANGE ? -DUTY_SP2_RANGE : correction); \
	newDutyL = 4000 + correction*dir; \
	newDutyR = 4000 - correction*dir; \
})

#define __PID_SPEED_2Back(cfg, error, correction, dir, newDutyL, newDutyR) ({ \
	correction = (cfg).Kp * error + (cfg).Ki * (cfg).ekSum + (cfg).Kd * (error-(cfg).ek1);\
    (cfg).ek1 = error; \
	(cfg).ekSum += error; \
	correction = correction > DUTY_SP2_RANGE ? DUTY_SP2_RANGE : (correction < -DUTY_SP2_RANGE ? -DUTY_SP2_RANGE : correction); \
	newDutyL = 5000 + correction*dir; \
	newDutyR = 5000 - correction*dir; \
})

#define __SET_SERVO_TURN(_TIMER, AMT) ({ \
	(_TIMER)->Instance->CCR4 = ((AMT) > SERVO_RIGHT_MAX) ? SERVO_RIGHT_MAX : ((AMT) < SERVO_LEFT_MAX ? SERVO_LEFT_MAX : (AMT));\
	HAL_Delay(SERVO_TURN_TIME); \
})

#define __SET_SERVO_TURN_MAX(_TIMER, _DIR) ({ \
	if (_DIR) (_TIMER)->Instance->CCR4 = SERVO_RIGHT_MAX; \
	else (_TIMER)->Instance->CCR4 = SERVO_LEFT_MAX; \
	HAL_Delay(SERVO_TURN_TIME); \
})

#define __RESET_SERVO_TURN(_TIMER) ({ \
	(_TIMER)->Instance->CCR4 = SERVO_CENTER; \
	HAL_Delay(SERVO_TURN_TIME); \
})

#define __ON_TASK_END(_MTimer, prevTask, curTask) ({ \
	__SET_MOTOR_DUTY(_MTimer, 0, 0); \
	prevTask = curTask; \
	curTask = TASK_NONE; \
})

#define __ACK_TASK_DONE(_UART, msg) ({ \
	snprintf((char *)msg, sizeof(msg) - 1, "done!"); \
	HAL_UART_Transmit(_UART, (uint8_t *) "ACK|\r\n", 6, 0xFFFF); \
})

#define __SET_MOTOR_DUTY(_TIMER, DUTY_L, DUTY_R)({ \
	(_TIMER)->Instance->CCR1 = DUTY_L; \
	(_TIMER)->Instance->CCR2 = DUTY_R; \
})

#define __SET_CMD_CONFIG(cfg, _MTIMER, _STIMER, targetAngle) ({ \
	__SET_SERVO_TURN(_STIMER, (cfg).servoTurnVal); \
	targetAngle = (cfg).targetAngle; \
	__SET_MOTOR_DIRECTION((cfg).direction); \
	__SET_MOTOR_DUTY(_MTIMER, (cfg).leftDuty, (cfg).rightDuty); \
})

#define __SET_CMD_CONFIG_WODUTY(cfg, _STIMER, targetAngle) ({ \
	__SET_SERVO_TURN(_STIMER, (cfg).servoTurnVal); \
	targetAngle = (cfg).targetAngle; \
	__SET_MOTOR_DIRECTION((cfg).direction); \
}) \

#define __CLEAR_CURCMD(cmd) ({ \
	cmd.index = 100; \
	cmd.val = 0; \
})

#define __PEND_CURCMD(cmd) ({ \
	cmd.index = 99; \
})

#define __GET_TARGETTICK(dist, targetTick) ({ \
	targetTick = (((dist) * DIST_M - DIST_C) * 1320 / WHEEL_LENGTH ) - 10; \
})

#define __SET_MOTOR_DIRECTION(DIR) ({ \
	HAL_GPIO_WritePin(GPIOA, AIN2_Pin, ((DIR) ? GPIO_PIN_RESET : GPIO_PIN_SET)); \
	HAL_GPIO_WritePin(GPIOA, AIN1_Pin, ((DIR) ? GPIO_PIN_SET: GPIO_PIN_RESET)); \
	HAL_GPIO_WritePin(GPIOA, BIN2_Pin, ((DIR) ? GPIO_PIN_RESET: GPIO_PIN_SET)); \
	HAL_GPIO_WritePin(GPIOA, BIN1_Pin, ((DIR) ? GPIO_PIN_SET: GPIO_PIN_RESET)); \
})

#define __SET_ENCODER_LAST_TICK(_TIMER, LAST_TICK) ({ \
	LAST_TICK = __HAL_TIM_GET_COUNTER(_TIMER); \
})

#define __GET_ENCODER_TICK_DELTA(_TIMER, LAST_TICK, _DIST) ({ \
	uint32_t CUR_TICK = __HAL_TIM_GET_COUNTER(_TIMER); \
	if (__HAL_TIM_IS_TIM_COUNTING_DOWN(_TIMER)) { \
		_DIST = (CUR_TICK <= LAST_TICK) ? LAST_TICK - CUR_TICK : (65535 - CUR_TICK) + LAST_TICK; \
	} else { \
		_DIST = (CUR_TICK >= LAST_TICK) ? CUR_TICK - LAST_TICK : (65535 - LAST_TICK) + CUR_TICK; \
	} \
	LAST_TICK = CUR_TICK; \
})

// FIFO
// write at head(add command), remove at tail (read command)
// head == tail implies empty queue
//
#define __READ_COMMAND(_CQ, CMD, msg) ({ \
	CMD = _CQ.buffer[_CQ.tail]; \
	_CQ.tail = (_CQ.tail + 1) % _CQ.size; \
	snprintf((char *)msg, sizeof(msg) - 1, "doing"); \
})

#define __COMMAND_QUEUE_IS_FULL(_CQ) (_CQ.head + 1) % _CQ.size == _CQ.tail

#define __COMMAND_QUEUE_IS_EMPTY(_CQ) (_CQ.head == _CQ.tail)

#define __ADD_COMMAND(_CQ, TASK_INDEX, TASK_VAL) ({ \
	_CQ.buffer[_CQ.head].index = TASK_INDEX; \
	_CQ.buffer[_CQ.head].val = TASK_VAL; \
	_CQ.head = (_CQ.head + 1) % _CQ.size; \
})

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
